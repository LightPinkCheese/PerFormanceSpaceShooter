using Unity.Collections;
using Unity.Entities;
using Unity.Physics;
using Unity.Transforms;
using Unity.Mathematics;
using Unity.Burst;
using System.Diagnostics;

[BurstCompile]
public partial struct BulletCollisionSystem : ISystem
{
    [BurstCompile]
   public void OnUpdate(ref SystemState state)
    {
      
        EntityManager entityManager = state.EntityManager;
        NativeArray<Entity> allentities = entityManager.GetAllEntities();

        PhysicsWorldSingleton physicsWorld = SystemAPI.GetSingleton<PhysicsWorldSingleton>();

        foreach (Entity entity in allentities)
        {
            if (entityManager.HasComponent<ProjectileTag>(entity)) 
            {
                LocalTransform bulletTransform = entityManager.GetComponentData<LocalTransform>(entity);
                ProjectileSize bulletSize = entityManager.GetComponentData<ProjectileSize>(entity);  

                NativeList<ColliderCastHit> hits = new(Allocator.Temp);
                physicsWorld.SphereCastAll(bulletTransform.Position, bulletSize.Size / 2, float3.zero, 1, 
                    ref hits, new CollisionFilter {BelongsTo = (uint)CollisionLayer.Default, CollidesWith = (uint)CollisionLayer.Enemy});

                var ecb = new EntityCommandBuffer(Allocator.TempJob);
                foreach (ColliderCastHit hit in hits)
                {
                    ecb.AddComponent<IsDestroying>(hit.Entity);
                }
                state.Dependency.Complete();
                ecb.Playback(state.EntityManager);
                ecb.Dispose();

                hits.Dispose();
            }

        }

    }
}

public enum CollisionLayer
{
    Default = 1 << 0,
    Enemy = 1 << 6
}