using JetBrains.Annotations;
using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

[BurstCompile]
public class PlaterAuth : MonoBehaviour
{
    public float MoveSpeed;

    public GameObject Projectile;

    public float projectileLifeTime;

    [BurstCompile]

    class PlaterAuthBaker : Baker<PlaterAuth>
    {
        [BurstCompile]

        public override void Bake(PlaterAuth authoring)
        {
            Entity playerEntity = GetEntity(TransformUsageFlags.Dynamic);

            AddComponent<PlayerTag>(playerEntity);
            AddComponent<PlayerMoveInput>(playerEntity);

            AddComponent(playerEntity, new PlayerMoveSpeed
            { 
                Value = authoring.MoveSpeed,
            });

            AddComponent<FireProjectileTag>(playerEntity);
            SetComponentEnabled<FireProjectileTag>(playerEntity, false);

            AddComponent(playerEntity, new ProjectilePrefab
            {
                Value = GetEntity(authoring.Projectile, TransformUsageFlags.Dynamic),
            });
            AddComponent(playerEntity, new ProjectilelifeTime
            {
                Value = authoring.projectileLifeTime
            }) ;
        }
    }
}

[BurstCompile]

public struct PlayerMoveInput : IComponentData
{
    public float2 Value;
}

[BurstCompile]

public struct PlayerMoveSpeed: IComponentData
{
    public float Value;
}

[BurstCompile]

public struct PlayerTag : IComponentData { }

[BurstCompile]

public struct ProjectilePrefab : IComponentData 
{
    public Entity Value;
}

[BurstCompile]

public struct ProjectileMoveSpeed : IComponentData
{
    public float Value;
}

[BurstCompile]

public struct FireProjectileTag: IComponentData, IEnableableComponent { }

[BurstCompile]
public struct ProjectilelifeTime: IComponentData 
{ 
    public float Value;
}

[BurstCompile]
public struct LifeTime : IComponentData
{
    public float Value;
}


[BurstCompile]
public struct IsDestroying : IComponentData { }


