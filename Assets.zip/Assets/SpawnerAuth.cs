using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Burst;

[BurstCompile]
public class SpawnerAuth : MonoBehaviour
{
    public GameObject prefab;
    public float spawnTime;

    [BurstCompile]
    class SpawnerBaker : Baker<SpawnerAuth>
    {
        [BurstCompile]
        public override void Bake(SpawnerAuth authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.Dynamic);

            AddComponent(entity, new Spawner
            {
                prefab = GetEntity(authoring.prefab, TransformUsageFlags.Dynamic),
                spawnPoint = float2.zero,
                nextSpawnTime = 0,
                spawnTime = authoring.spawnTime,
            }) ;
        }
    }
}
