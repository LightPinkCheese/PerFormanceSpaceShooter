using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

[BurstCompile]
public class EnemyAuth : MonoBehaviour
{
    public float MoveSpeed;

    [BurstCompile]
    class EnemyAuthBaker : Baker<EnemyAuth>
    {
        [BurstCompile]
        public override void Bake(EnemyAuth authoring)
        {
            Entity Enemyentity = GetEntity(TransformUsageFlags.Dynamic);

            AddComponent(Enemyentity, new EnemyMoveSpeed
            {
               Value = authoring.MoveSpeed,
            });
            AddComponent(Enemyentity, new EnemyTag { });
        }
    }
}

[BurstCompile]
public struct EnemyMoveSpeed : IComponentData
{
    public float Value;
}

[BurstCompile]

public struct EnemyTag : IComponentData { }

