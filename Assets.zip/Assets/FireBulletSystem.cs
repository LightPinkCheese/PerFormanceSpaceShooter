using Unity.Burst;
using Unity.Entities;
using Unity.Transforms;

[UpdateInGroup(typeof(SimulationSystemGroup)), UpdateBefore(typeof(TransformSystemGroup)), BurstCompile]
public partial struct FireBulletSystem : ISystem
{
    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
        foreach(var (projectilePrefab, transform, lifetame) in SystemAPI.Query<ProjectilePrefab, LocalTransform, ProjectilelifeTime>().WithAll<FireProjectileTag>())
        {
            var newprojectil = ecb.Instantiate(projectilePrefab.Value);
            var projectilTransform = LocalTransform.FromPositionRotationScale(transform.Position, transform.Rotation, 0.2f);
            ecb.SetComponent(newprojectil, projectilTransform);
            ecb.AddComponent(newprojectil, new LifeTime {Value = lifetame.Value });

        }
        ecb.Playback(state.EntityManager);
        ecb.Dispose();
    }
}
