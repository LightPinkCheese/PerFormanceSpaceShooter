
using Unity.Burst;
using Unity.Entities;
using UnityEngine;

[BurstCompile]
public class ProjectilAuth : MonoBehaviour
{
    public float ProjectileSpeed;
    public float BulletSize;

    [BurstCompile]
    public class ProjectilAuthBaker : Baker<ProjectilAuth>
    {
        [BurstCompile]
        public override void Bake(ProjectilAuth authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.Dynamic);
            AddComponent(entity, new ProjectileMoveSpeed { Value = authoring.ProjectileSpeed });
            AddComponent(entity, new ProjectileSize { Size = authoring.BulletSize });
        }
    }
}

public struct ProjectileTag : IComponentData { }

public struct ProjectileSize: IComponentData 
{
    public float Size;
}

