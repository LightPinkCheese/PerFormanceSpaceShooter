using UnityEngine;
using Unity.Entities;
using Unity.Burst;
using UnityEngine.InputSystem;


[UpdateInGroup(typeof(InitializationSystemGroup), OrderLast = true), BurstCompile]
public partial class PlayerInputSystem : SystemBase
{   
    private GameInput InputActions;
    private Entity Player;

    [BurstCompile]
    protected override void OnCreate()
    {
        RequireForUpdate<PlayerTag>();
        RequireForUpdate<PlayerMoveInput>();
        InputActions = new GameInput();

    }

    [BurstCompile]
    protected override void OnStartRunning()
    {
        InputActions.Enable();
        InputActions.GamePlay.Shoot.performed += OnShoot;
        Player = SystemAPI.GetSingletonEntity<PlayerTag>();
    }

    [BurstCompile]
    private void OnShoot(InputAction.CallbackContext context)
    {
        if (!SystemAPI.Exists(Player)) return;

        SystemAPI.SetComponentEnabled<FireProjectileTag>(Player, true);
    }

    [BurstCompile]
    protected override void OnUpdate()
    {
        Vector2 movwInput = InputActions.GamePlay.Move.ReadValue<Vector2>();

        SystemAPI.SetSingleton(new PlayerMoveInput { Value = movwInput });
    }

    [BurstCompile]
    protected override void OnStopRunning()
    {
        InputActions.Disable();
        Player = Entity.Null;
    }
}
