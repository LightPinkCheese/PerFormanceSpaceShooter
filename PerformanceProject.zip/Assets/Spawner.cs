using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;

[BurstCompile]
public struct Spawner : IComponentData
{
    public Entity prefab;
    public float2 spawnPoint;
    public float nextSpawnTime;
    public float spawnTime;
}
