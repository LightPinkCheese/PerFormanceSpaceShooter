using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

[BurstCompile]
public class EnemyAuth : MonoBehaviour
{

    [BurstCompile]
    class EnemyAuthBaker : Baker<EnemyAuth>
    {
        [BurstCompile]
        public override void Bake(EnemyAuth authoring)
        {
            Entity Enemyentity = GetEntity(TransformUsageFlags.Dynamic);

            AddComponent(Enemyentity, new EnemyTag { });
        }
    }
}

[BurstCompile]

public struct EnemyTag : IComponentData { }

