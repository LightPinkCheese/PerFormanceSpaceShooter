using System.Diagnostics;
using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

[BurstCompile]
public partial struct EnemyMoveSystem : ISystem
{   
    private EntityManager entityManager;
    private Entity TargetEntity;

    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        entityManager = state.EntityManager;
        TargetEntity = SystemAPI.GetSingletonEntity<PlayerTag>();
        foreach (var (enemyComp, Transform) in SystemAPI.Query<EnemyTag, RefRW<LocalTransform>>())
        {
           float3 direction = entityManager.GetComponentData<LocalTransform>(TargetEntity).Position - Transform.ValueRO.Position;
            float angle = math.atan2(direction.y, direction.x);
             Transform.ValueRW.Rotation = quaternion.Euler(new float3(0, 0, angle));
             Transform.ValueRW.Position += math.normalizesafe(direction) * SystemAPI.Time.DeltaTime; //made the normalize safe to avoid errors

        }
    }

}